package AMI_FileManage_test;

public class gloabl {
	public static String element_id_SubstationCode = "mID";
	public static String element_id_SubstationName  = "mDESCRIPTION";
	public static String element_id_VoltageLevel  = "mVOL_LEVEL";
	public static String element_id_Status = "mSTATUS";
	public static String element_id_SubstationBranch_clear = "clearInput(this)";
	public static String element_id_SubstationBranch_select = "mBRANCH";
	public static String element_id_Search = "table.ajax.reload(null,false);";
	
	public static String element_id_LineNumber = "mID";
	public static String element_id_NameOfLine  = "mDESCRIPTION";
	public static String element_id_LineSubstation  = "mSTATION";
	public static String element_id_LineType = "mTYPE";
	public static String element_id_LineStatu = "mSTATUS";
	public static String element_id_LineBranch = "mID";
	
	public static String element_id_User = "mID";
}
